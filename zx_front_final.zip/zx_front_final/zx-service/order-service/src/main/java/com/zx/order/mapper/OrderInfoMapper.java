package com.zx.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zx.domain.entity.order.OrderInfo;


public interface OrderInfoMapper extends BaseMapper<OrderInfo> {
}
