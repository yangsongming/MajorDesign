package com.zx.order.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zx.domain.entity.order.OrderInfo;
import com.zx.domain.entity.order.OrderItem;


public interface OrderItemService extends IService<OrderItem> {
}
