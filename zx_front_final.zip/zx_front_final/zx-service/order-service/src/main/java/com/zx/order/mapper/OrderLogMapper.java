package com.zx.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zx.domain.entity.order.OrderItem;
import com.zx.domain.entity.order.OrderLog;

public interface OrderLogMapper  extends BaseMapper<OrderLog> {
}
