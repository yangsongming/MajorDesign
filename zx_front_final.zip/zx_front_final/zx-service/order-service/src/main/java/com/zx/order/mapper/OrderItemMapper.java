package com.zx.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zx.domain.entity.order.OrderItem;

public interface OrderItemMapper  extends BaseMapper<OrderItem> {
}
