package com.zx.order.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zx.domain.entity.order.OrderInfo;
import com.zx.domain.entity.order.OrderLog;

public interface OrderLogService extends IService<OrderLog> {
}
