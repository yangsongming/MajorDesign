package com.zx.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zx.domain.entity.pay.PaymentInfo;

public interface PaymentInfoMapper extends BaseMapper<PaymentInfo> {
}
