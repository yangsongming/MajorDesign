package com.zx.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zx.domain.entity.user.UserCollect;


public interface UserCollectMapper extends BaseMapper<UserCollect> {

}
