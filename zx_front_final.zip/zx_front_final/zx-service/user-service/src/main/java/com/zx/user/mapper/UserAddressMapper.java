package com.zx.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zx.domain.entity.user.UserAddress;

public interface UserAddressMapper extends BaseMapper<UserAddress> {
}
