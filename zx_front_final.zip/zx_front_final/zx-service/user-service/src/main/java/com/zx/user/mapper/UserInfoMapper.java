package com.zx.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zx.domain.entity.product.Brand;
import com.zx.domain.entity.user.UserInfo;

public interface UserInfoMapper extends BaseMapper<UserInfo> {
}
