package com.zx.user.mapper;

import com.zx.domain.entity.base.Region;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 地区信息表 Mapper 接口
 * </p>
 *
 * @author author
 * @since 2025-01-03
 */
public interface RegionMapper extends BaseMapper<Region> {

}
