package com.zx.product.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zx.domain.entity.product.Brand;

public interface BrandMapper extends BaseMapper<Brand> {
}
