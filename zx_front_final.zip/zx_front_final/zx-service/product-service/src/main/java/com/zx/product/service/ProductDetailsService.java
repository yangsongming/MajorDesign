package com.zx.product.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zx.domain.entity.product.ProductDetails;
import org.springframework.stereotype.Service;

@Service
public interface ProductDetailsService extends IService<ProductDetails> {
}
