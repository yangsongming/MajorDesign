package com.zx.domain.dto.product;

import lombok.Data;

@Data
public class SkuSaleDto {

	private Long skuId;
	private Integer num;

}

